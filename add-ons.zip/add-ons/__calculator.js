const addCalculator = function () {

	if (!document.querySelector(".add-ons")) {
		const addOnHTML = `<div class="add-ons"></div>`;
		const addOnCSS = `<link id="pagestyle" href="assets/add-ons/add-ons.css" rel="stylesheet" />`;
		document.body.insertAdjacentHTML("afterbegin", addOnHTML);
		document.body.insertAdjacentHTML("beforeend", addOnCSS);
	}

	const calculatorHTML = `
	<div class="calculator"><i class="material-icons opacity-10 close-icon" hidden>close</i><i class="material-icons opacity-10 calc-icon">calculate</i><iframe id="calculator-app" src="https://calculator-psi-hazel.vercel.app/" frameborder="0" hidden></iframe></div>`;

	document.querySelector(".add-ons").insertAdjacentHTML("afterbegin", calculatorHTML);

	// Toggle Calculator Visibility
	const toggleCalculator = () => {
		[...document.querySelector(".calculator").children].forEach((node) => {
			node.hidden = !node.hidden;
		});
	};
	document.querySelector(".calculator .calc-icon").addEventListener("click", toggleCalculator);
	document.querySelector(".calculator .close-icon").addEventListener("click", toggleCalculator);
};

addCalculator();
