const addNotepad = function () {

	if (!document.querySelector(".add-ons")) {
		const addOnHTML = `<div class="add-ons"></div>`;
		const addOnCSS = `<link id="pagestyle" href="assets/add-ons/add-ons.css" rel="stylesheet" />`;
		document.body.insertAdjacentHTML("afterbegin", addOnHTML);
		document.body.insertAdjacentHTML("beforeend", addOnCSS);
	}

	const notepadHTML = `<div class="notepad"><i class="material-icons opacity-10 close-icon" hidden>close</i><i class="material-icons opacity-10 note-icon">create</i><div class="note-taker text-black text-bold" hidden><h3>Notepad</h3><div class="notepad-content" contenteditable="true"></div></div></div>`;

	document.querySelector(".add-ons").insertAdjacentHTML("afterbegin", notepadHTML);

	// Toggle Notepad Visibility
	const toggleNotepad = () => {
		[...document.querySelector(".notepad").children].forEach((node) => {
			node.hidden = !node.hidden;
		});
	};
	document.querySelector(".notepad .note-icon").addEventListener("click", toggleNotepad);
	document.querySelector(".notepad .close-icon").addEventListener("click", toggleNotepad);
};
addNotepad();
