const express = require("express");
const bodyParser = require("body-parser");
const app = express();
const port = 3000;

const Pool = require("pg").Pool;
const pool = new Pool({
	user: "hello1234",
	host: "db",
	database: "hello1234",
	password: "hello1234",
	port: 5432
});

app.use(bodyParser.json());
app.use(
	bodyParser.urlencoded({
		extended: true
	})
);

app.get("/", (request, response) => {
	const { surveyId, responseId } = request.query;
	response.json({ surveyId, responseId });
});

app.listen(port, () => {
	console.log(`App running on port ${port}.`);
});

const addResponse = (request, response) => {
	const { surveyId, responseId } = request.query;

	pool.query(`INSERT INTO ${surveyId} ("responseId") VALUES ($1) RETURNING *`, [responseId], (error, results) => {
		if (error) {
			console.log(error);
		} else {
			console.log(results);
			response.status(201).send(`Response added with ID: ${results.rows[0].ID}`);
		}
	});
};

app.get("/newResponse", addResponse);
